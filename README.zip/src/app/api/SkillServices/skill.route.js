export const SkillRoutes = {
  addSkill: "/system/addSkill",
  getSkill: "/system/skills",
  addCode :"/system/addCode",
  getCode :"/system/codes"
};
