export const  CompanyRoutes = {
   
    createCompany: "/companies/create",
    getCompany: "/companies",
    deleteCompany:"/companies/delete",
    updateCompany:"/companies/update"
  };
    