export const  FileRoutes = {
   
    uploadImage: "/upload",
    uploadDocument: "/docUpload",
    
    
  };
    