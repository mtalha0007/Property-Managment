export const JobTimeRoute = {
  setJobTime :"/jobs/addTimesheetStatus",
  getTimeSheet:"jobs/getTimeRecord",
  updateTimeSheet:"/jobs/updateTimesheetStatusbyAdmin"
  };
  