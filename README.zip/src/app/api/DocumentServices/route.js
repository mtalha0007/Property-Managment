export const DocumentRoutes = {
    getDoc: "jobs/getDocuments",
    SignDoc :"/jobs/signDocument",
    approveDoc:"/jobs/approveDocument",
  
  };
  