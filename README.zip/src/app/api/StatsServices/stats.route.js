export const StatsRoute = {
  
    getStats :"/system/stats",
   
  };
  