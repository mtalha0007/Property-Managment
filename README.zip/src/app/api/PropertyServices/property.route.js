export const  PropertyRoutes = {
   
    createProperty: "/properties/property/create",
    getProperty: "/properties/getproperties",
    deleteProperty:"/properties/deleteproperty",
    updateProperty:"/properties/updateproperty",
    getPropertyById:"/properties/getproperty",
    getInvestrorProperty:"/auth/investors/property",
  };
    